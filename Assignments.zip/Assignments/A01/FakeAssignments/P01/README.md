## Fake Program 1

Python Hello World Program

```python
print("hello world")
```
