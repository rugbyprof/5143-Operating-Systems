## Fake Program 2

Python Hello Mars Program

```python
print("hello mars!!")
```