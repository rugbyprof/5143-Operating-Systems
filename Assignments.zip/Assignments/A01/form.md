```
   _____ ____  _   _ _______       _____ _______     _____ _   _ ______ ____
  / ____/ __ \| \ | |__   __|/\   / ____|__   __|   |_   _| \ | |  ____/ __ \
 | |   | |  | |  \| |  | |  /  \ | |       | |        | | |  \| | |__ | |  | |
 | |   | |  | | . ` |  | | / /\ \| |       | |        | | | . ` |  __|| |  | |
 | |___| |__| | |\  |  | |/ ____ \ |____   | |       _| |_| |\  | |   | |__| |
  \_____\____/|_| \_|  |_/_/    \_\_____|  |_|      |_____|_| \_|_|    \____/
```

- <img src="https://www.gstatic.com/images/branding/product/2x/forms_2020q4_48dp.png" width="30"> Go complete <a href="https://forms.gle/NRsoyMXWQzohcasc8">THIS</a> form.

- Fill out the form fields accurately please. I use this info to automate some grading tasks and if your info is wrong, you break my scripts and might not get grades for some items.

> Notes:
>
> - <sup> **1**. Your repository name and your Github username are **NOT** the same thing.</sup>
> - <sup> **2**. I should be able to click your repo link, and it will take me to your course repository. NOT your github home page.
> - <sup> **3**. Uploading an image of you (with your face in it) will help me learn names faster!</sup>
